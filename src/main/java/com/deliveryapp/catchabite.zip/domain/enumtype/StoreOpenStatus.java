package com.deliveryapp.catchabite.domain.enumtype;

public enum StoreOpenStatus {
    OPEN,
    CLOSE
}
